Spectrum
========

Provides initialization for easy 256 colours and effects.

See [a guide to 256 color codes](http://lucentbeing.com/writing/archives/a-guide-to-256-color-codes/), in particular, the "Spectrum, a ZSH Abstraction" section.


