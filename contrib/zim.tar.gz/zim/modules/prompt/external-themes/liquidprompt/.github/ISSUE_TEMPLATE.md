Shell: bash/zsh
Operating system: 
Liquid Prompt version (tag, commit): 

