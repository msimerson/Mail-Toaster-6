Completion
==========

Enables and configures smart and extensive tab completion.

Completions are sourced from [zsh-completions](https://github.com/zsh-users/zsh-completions).

This should be the **LAST** module in the `zmodules` list in your `.zimrc`.

Contributing
------------

Command completions should be submitted [upstream to zsh-completions](https://github.com/zsh-users/zsh-completions).
